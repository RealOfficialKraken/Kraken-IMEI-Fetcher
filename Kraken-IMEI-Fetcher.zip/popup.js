// Load saved IMEI when popup opens
document.addEventListener('DOMContentLoaded', async () => {
  const input = document.getElementById('imeiInput');
  const stored = await browser.storage.local.get('imei');
  if (stored.imei) {
    input.value = stored.imei;
  }
});

// Handle click, validate and store
document.getElementById('checkButton').addEventListener('click', async () => {
  const imei = document.getElementById('imeiInput').value.trim();

  if (!/^\d{15}$/.test(imei)) {
    alert("Please enter a valid 15-digit IMEI number.");
    return;
  }

  // Save to local storage
  await browser.storage.local.set({ imei });

  // Send to background script
  browser.runtime.sendMessage({ action: 'checkIMEI', imei });
});

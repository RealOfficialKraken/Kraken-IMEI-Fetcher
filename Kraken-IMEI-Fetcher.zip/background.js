chrome.runtime.onMessage.addListener(async (message, sender) => {
  if (message.action === 'checkIMEI') {
    const imei = message.imei;

    const tab = await chrome.tabs.create({
      url: `https://imeiapi.net/#${imei}`,
      active: true
    });

    const listener = (tabId, changeInfo) => {
      if (tabId === tab.id && changeInfo.status === 'complete') {
        let attemptCount = 0;
        const maxAttempts = 3;

        const injectScript = () => {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              const imei = location.hash.slice(1);

              function waitForElement(selector, timeout = 5000) {
                return new Promise((resolve, reject) => {
                  const interval = 100;
                  let elapsed = 0;
                  const check = () => {
                    const el = document.querySelector(selector);
                    if (el) return resolve(el);
                    elapsed += interval;
                    if (elapsed >= timeout) return reject(`Timeout: ${selector} not found`);
                    setTimeout(check, interval);
                  };
                  check();
                });
              }

              function delay(ms) {
                return new Promise(resolve => setTimeout(resolve, ms));
              }

              (async () => {
                try {
                  const input = await waitForElement('input[type="text"]');
                  input.focus();
                  await delay(100);

                  // Instantly set the IMEI value
                  input.value = imei;
                  input.dispatchEvent(new Event('input', { bubbles: true }));

                  await delay(200);

                  // Simulate Tab key
                  ['keydown', 'keyup'].forEach(eventType => {
                    const tabEvent = new KeyboardEvent(eventType, {
                      key: 'Tab',
                      code: 'Tab',
                      keyCode: 9,
                      which: 9,
                      bubbles: true,
                      cancelable: true
                    });
                    document.activeElement.dispatchEvent(tabEvent);
                  });

                  await delay(200); // Wait for focus to move

                  // Simulate Enter key
                  ['keydown', 'keypress', 'keyup'].forEach(eventType => {
                    const enterEvent = new KeyboardEvent(eventType, {
                      key: 'Enter',
                      code: 'Enter',
                      keyCode: 13,
                      which: 13,
                      bubbles: true,
                      cancelable: true
                    });
                    document.activeElement.dispatchEvent(enterEvent);
                  });

                  console.log("IMEI injected, Tab pressed, and Enter submitted");

                } catch (err) {
                  console.error("Injection failed inside tab:", err);
                  throw err;
                }
              })();
            }
          }).catch(err => {
            attemptCount++;
            console.warn(`Attempt ${attemptCount} failed:`, err);
            if (attemptCount < maxAttempts) {
              setTimeout(injectScript, 1000);
            } else {
              console.error("IMEI injection failed after 3 attempts.");
            }
          });
        };

        injectScript();

        chrome.tabs.onUpdated.removeListener(listener);
      }
    };

    chrome.tabs.onUpdated.addListener(listener);
  }
});

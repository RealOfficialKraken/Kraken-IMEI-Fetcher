# Kraken's IMEI Lookup

The chrome extension aims at being very fast in fetching the make/model for a device, at any given time, without having to remember and look up an imei website.

The extension is awaiting review. When it becomes published, I will link to it here.
